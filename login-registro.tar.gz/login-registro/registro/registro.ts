import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-registro',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './registro.html',
  styleUrl: './registro.css'
})
export class Registro {
  nombre = '';
  email = '';
  telefono = '';
  password = '';
  confirmPassword = '';
  showPassword = false;
  aceptaTerminos = false;
  isLoading = false;
  errorMsg = '';

  onSubmit() {
    if (!this.nombre || !this.email || !this.password) {
      this.errorMsg = 'Por favor, completa todos los campos obligatorios.';
      return;
    }
    if (this.password !== this.confirmPassword) {
      this.errorMsg = 'Las contraseñas no coinciden.';
      return;
    }
    if (!this.aceptaTerminos) {
      this.errorMsg = 'Debes aceptar la política de privacidad.';
      return;
    }
    this.isLoading = true;
    this.errorMsg = '';

    // TODO: conectar con Laravel API
    // POST /api/register { nombre, email, telefono, password }
    setTimeout(() => {
      this.isLoading = false;
      // this.router.navigate(['/login']);
    }, 1200);
  }
}
