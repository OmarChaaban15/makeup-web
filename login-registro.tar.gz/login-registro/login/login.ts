import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class Login {
  email = '';
  password = '';
  showPassword = false;
  isLoading = false;
  errorMsg = '';

  onSubmit() {
    if (!this.email || !this.password) {
      this.errorMsg = 'Por favor, completa todos los campos.';
      return;
    }
    this.isLoading = true;
    this.errorMsg = '';

    // TODO: conectar con Laravel API
    // POST /api/login { email, password }
    setTimeout(() => {
      this.isLoading = false;
      this.errorMsg = 'Credenciales incorrectas. Inténtalo de nuevo.';
    }, 1200);
  }
}
